@extends('layouts.other')

@section('header')
@include('pages.careers.header')
@endsection

@section('content')
@include('pages.careers.content')
@endsection

@section('footer')
@include('pages.homepage.footer')
@endsection