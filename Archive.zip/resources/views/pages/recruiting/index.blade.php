@extends('layouts.other')

@section('header')
@include('pages.recruiting.header')
@endsection

@section('content')
@include('pages.recruiting.content')
@endsection

@section('footer')
@include('pages.homepage.footer')
@endsection
