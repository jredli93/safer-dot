@extends('layouts.other')

@section('header')
@include('pages.about.header')
@endsection

@section('content')
@include('pages.about.content')
@endsection

@section('footer')
@include('pages.homepage.footer')
@endsection