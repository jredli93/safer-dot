@extends('layouts.other')

@section('header')
@include('pages.contact.header')
@endsection

@section('content')
@include('pages.contact.content')
@endsection

@section('footer')
@include('pages.homepage.footer')
@endsection
