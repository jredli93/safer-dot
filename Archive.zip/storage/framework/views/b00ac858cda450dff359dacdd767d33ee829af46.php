<section class="header-services">
    <?php echo $__env->make('utils.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/safer-dot/resources/views/pages/recruiting/header.blade.php ENDPATH**/ ?>