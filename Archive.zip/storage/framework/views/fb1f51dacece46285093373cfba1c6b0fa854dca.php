<ul class="navigation-list">
    <li class="navigation-item"><img class="navigation-item-logo" src="<?php echo e(asset('/assets/images/safer-logo.png')); ?>" alt="logo" /></li>
    <li class="navigation-item"><a href="<?php echo e(URL::route('home')); ?>">Home</a></li>
    <li class="navigation-item"><a href="<?php echo e(URL::route('about-us')); ?>">Partners</a></li>
    <li class="navigation-item"><a href="<?php echo e(URL::route('recruiting')); ?>">Recruiting</a></li>
    <li class="navigation-item"><a href="<?php echo e(URL::route('about-us')); ?>">About Us</a></li>
    <li class="navigation-item"><a href="<?php echo e(URL::route('contact')); ?>">Contact</a></li>
</ul>
<div class="navigation-mobile" id="navigation-mobile">
    <img class="navigation-mobile-logo" src="<?php echo e(asset('/assets/images/safer-logo.png')); ?>" alt="logo" />
    <span class="navigation-hamburger"><i class="fas fa-bars text-slate-800" area-hidden="true"></i></span>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/safer-dot/resources/views/utils/menu.blade.php ENDPATH**/ ?>