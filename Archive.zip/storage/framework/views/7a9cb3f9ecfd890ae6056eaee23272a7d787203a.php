<section class="header-careers">
   <?php echo $__env->make('utils.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php if(session('success')): ?>
        <div class="alert success-alert">
            <h3 class="alert-text"> <?php echo e(session('success')); ?></h3>
            <a class="close">&times;</a>
        </div>
    <?php endif; ?>
    <h1 class="careers-title">careers</h1>
</section><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/safer-dot/resources/views/pages/careers/header.blade.php ENDPATH**/ ?>