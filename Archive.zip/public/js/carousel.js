$('.main-carousel').flickity({
    cellAlign: 'left',
    contain: true,
    autoPlay: 7000,
    pageDots: true,
    setGallerySize: false,
    wrapAround: true,
    freeScroll: false,
    imagesLoaded: true,
    prevNextButtons: false
});